const express = require("express");
const app = express();
const port = 3000;
const path = require("path");
const { v4: uuidv4 } = require("uuid");
const multer = require("multer");
const methodOverride = require('method-override');

app.use(methodOverride('_method'));
app.use(express.urlencoded({extended:true}))
app.set("view engine","ejs");
app.set("views", path.join(__dirname, "views"));
app.use(express.static(path.join(__dirname, "/upload")));
app.use("/upload", express.static(path.join(__dirname, "upload")));
app.use(express.static(path.join(__dirname,"public")));
app.use("/style.css", express.static(path.join(__dirname, "/style.css")));
app.use("/style1.css", express.static(path.join(__dirname, "/style1.css")));

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, path.join(__dirname, "upload"));
    },
    filename: (req, file, cb) => {
        cb(null, `${Date.now()}-${file.originalname}`);
    },
});
const upload = multer({ storage });


let posts = [
    {
        id: uuidv4(),
        username: "virat",
        content: "golds plan",
        image: "virat.webp", // Default image
    },
    {
        id: uuidv4(),
        username: "niraj bhai",
        content: "keep hardwork one day become success",
        image: "ezz.jpeg",
    },
    {
        id: uuidv4(),
        username: "pawan",
        content: "please dont become boss father",
        image: "pawan.webp",
    },
    {
        id: uuidv4(),
        username: "ishow",
        content: "you do what you have to do",
        image: "ishow.jpg",
    },
];


app.get("/posts", (req, res) => {
    console.log(posts); // Debug to ensure posts is an array
    res.render("index.ejs", { posts });
});


app.get("/posts/new",(req,res)=>{
    res.render("new.ejs");
})

app.post("/posts",(req,res)=>{
    let {username,content,image} = req.body;
    let id = uuidv4();
    posts.push({id,username,content,image});
    res.redirect("/posts");   
})

app.get("/posts/:id",(req,res)=>{
    let {id} = req.params;
    let post = posts.find((p) => id == p.id);   
    res.render("viewpost.ejs",{post});
})

app.get("/posts/:id/edit", (req, res) => {
    const { id } = req.params;
    const post = posts.find((p) => id === p.id);
    res.render("edit.ejs", { post });
});

app.patch("/posts/:id", upload.single("image"), (req, res) => {
    const { id } = req.params;
    const { username, content } = req.body;
    const post = posts.find((p) => id === p.id);

    if (post) {
        post.username = username;
        post.content = content;
        if (req.file) {
            post.image = req.file.filename; // Update the image if a new one is uploaded
        }
        res.redirect("/posts");
    } else {
        res.status(404).send("Post not found");
    }
});

app.delete("/posts/:id",(req,res)=>{
    let { id } = req.params;
    posts = posts.filter((P)=> id !== P.id);
   res.redirect("/posts");
})

app.listen(port,(req,res)=>{
    console.log(`server is running 3000`);
})